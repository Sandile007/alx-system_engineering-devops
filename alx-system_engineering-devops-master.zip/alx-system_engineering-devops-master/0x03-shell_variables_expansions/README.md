Shell variables expansions
