Shell permissions
